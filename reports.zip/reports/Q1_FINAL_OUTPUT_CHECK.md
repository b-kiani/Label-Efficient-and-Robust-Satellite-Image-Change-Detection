# Q1 Final Output Check

Generated: 2026-07-02 20:53:42
Project: `D:\Datasets\Satillate\_objchange_q1_revision_experiments`

## File completion
- FOUND — Dataset imbalance statistics: `D:\Datasets\Satillate\_objchange_q1_revision_experiments\reports\dataset_changed_pixel_and_object_statistics.csv`
- FOUND — Corruption parameter table: `D:\Datasets\Satillate\_objchange_q1_revision_experiments\tables\corruption_parameter_table.csv`
- FOUND — Label efficiency raw results: `D:\Datasets\Satillate\_objchange_q1_revision_experiments\reports\label_efficiency_3seed_q1.csv`
- FOUND — Label efficiency summary: `D:\Datasets\Satillate\_objchange_q1_revision_experiments\reports\label_efficiency_3seed_summary_q1.csv`
- FOUND — Boundary/object/bootstrap metrics: `D:\Datasets\Satillate\_objchange_q1_revision_experiments\reports\boundary_object_bootstrap_metrics_q1.csv`
- FOUND — Boundary/object/bootstrap summary: `D:\Datasets\Satillate\_objchange_q1_revision_experiments\reports\boundary_object_bootstrap_metrics_summary_q1.csv`
- FOUND — Training time and GPU memory: `D:\Datasets\Satillate\_objchange_q1_revision_experiments\reports\training_time_gpu_memory_summary_q1.csv`
- FOUND — Paired model comparison: `D:\Datasets\Satillate\_objchange_q1_revision_experiments\reports\paired_model_comparison_dataset_level_q1.csv`

## Label-efficiency minimum
- Required rows: 108
- Completed rows: 108
- Missing rows: 0
- Completion: 100.0%

## Readiness conclusion
The Q1 minimum experiment outputs are complete. The manuscript can be revised with label-efficiency, boundary/object metrics, runtime/GPU memory, corruption parameters, and paired descriptive comparisons.